function clic(params) {
    swal("Hello world!");

}